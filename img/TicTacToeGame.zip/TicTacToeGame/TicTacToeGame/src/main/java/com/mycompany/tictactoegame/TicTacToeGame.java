/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tictactoegame;

/**
 *
 * @author binur
 */
public class TicTacToeGame {

    public static void main(String[] args) {
        
    }
}
